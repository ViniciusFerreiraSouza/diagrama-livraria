namespace diagrama_livros
{
    public class Class
    {
        
    }
}