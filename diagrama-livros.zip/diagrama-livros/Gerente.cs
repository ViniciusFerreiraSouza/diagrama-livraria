namespace diagrama_livros
{
    public class Gerente
    {
        public Gerente()

        public Pedido pedido;

        public Fornecer fornecedor;

        public Cliente cliente;        

    }
}