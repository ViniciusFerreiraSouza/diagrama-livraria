namespace diagrama_livros
{
    public class Cliente
    {
        public Cliente(int codigo, string nome, string endereco, string cidade, string estado, string cep, string telefone, int pedcli)
    }

    public int codigo { get; set; }
    public string nome { get; set; }
    public string endereco { get; set; }
    public string cidade { get; set; }
    public string estado { get; set; }
    public string cep { get; set; }
    public string telefone { get; set; }
    public string pedcli { get; set; }

    public PedidoCliente pedidocliente;
}