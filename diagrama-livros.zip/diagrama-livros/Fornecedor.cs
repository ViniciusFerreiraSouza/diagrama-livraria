namespace diagrama_livros
{
    public class Fornecedor
    {
        public Fornecedor(int codigo, string nome, string endereco, string cidade, string estado, string cep, string telefone, int pedfor, int cnpj)
        {
            this.codigo = codigo;
            this.nome = nome;
            this.endereco = endereco;
            this.cidade = cidade;
            this.estado = estado;
            this.cep = cep;
            this.telefone = telefone;
            this.pedfor = pedfor;
            this.cnpj = cpnj;
        }

        public int codigo { get; set; }
        public string nome { get; set; }
        public string endereco { get; set; }
        public string cidade { get; set; }
        public string estado { get; set; }
        public string cep { get; set; }
        public string telefone { get; set; }
        public int pedfor { get; set; }
        public int cnpj { get; set; }
        
        public Pedido pedido;
    }
}