namespace diagrama_livros
{
    public class PedidoCliente
    {
        Public PedidoCliente(int codcliente, DataTime dataremessa)
        {
            this.codcliente = codcliente;
            DataTime dataremessa = new Datatime;
        }

        public int codcliente { get; set; }

        public DataTime dataremessa { get; set; }
    }
}