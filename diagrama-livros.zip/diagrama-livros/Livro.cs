namespace diagrama_livros
{
    public class Livro
    {
        public Livro(int codigo, string titulo, string autor, string isbn, decimal preco, int codfornecedor)
        {
            this.codigo = codigo;
            this.titulo = titulo;
            this.autor = autor;
            this.isbn = isbn;
            this.preco = preco;
            this.codfornecedor = fornecedor;

        }

        public int codigo { get; set; }
        public int titulo { get; set; }
        public string autor { get; set; }
        public string isbn { get; set; }
        public decimal preco { get; set; }
        public int codfornecedor { get; set; }

    }
}