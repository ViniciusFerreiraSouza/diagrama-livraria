namespace diagrama_livros
{
    public class Pedido
    {
        public Pedido(int codigo, Datatime datapedido, int listalivro, int quantidade, decimal valor)
        {
            this.codigo = codigo;
            Datatime datapedido  = New Datatime;
            this.listalivro = listalivro;
            this.quantidade = quantidade;
            this.valor = new valor;
        
        } 

        public int codigo { get; set; }
        public Datatime datapedido { get; set; }
        public int listalivro {get; set; }
        public int quantidade {get; set; }
        public decimal valor {get; set; }    

        public Livro livro;

        public PedidoCliente pedidocliente;

        public PedidoFornecedor pedidofornecedor;

    }
}