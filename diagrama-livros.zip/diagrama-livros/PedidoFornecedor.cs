namespace diagrama_livros
{
    public class PedidoFornecedor
    {
        public PedidoFornecedor(int codfornecedor, DataTime datarecebimento)
    }

    public int codigofornecedor { get; set; }
    public DataTime datarecebimento { get; set; }
}